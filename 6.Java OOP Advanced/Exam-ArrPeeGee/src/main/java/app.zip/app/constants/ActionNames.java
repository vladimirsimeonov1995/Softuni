package app.constants;

public final class ActionNames {

    public static final String ACTION_BOSS_FIGHT = "BossFight";
    public static final String ACTION_ONE_VS_ONE = "OneVsOne";

    private ActionNames() {
    }
}
