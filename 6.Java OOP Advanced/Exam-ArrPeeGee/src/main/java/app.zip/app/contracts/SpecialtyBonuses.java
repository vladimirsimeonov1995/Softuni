package app.contracts;

public interface SpecialtyBonuses {

    int getToughnessBonus();

    int getHealBonus();

    int getSwiftnessBonus();
}
