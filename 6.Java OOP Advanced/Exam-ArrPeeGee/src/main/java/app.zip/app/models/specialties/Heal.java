package app.models.specialties;

public class Heal extends AbstractSpecialty {

    @Override
    public int getHealBonus() {
        return super.getBonus();
    }
}
