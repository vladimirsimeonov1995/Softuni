package app.models.specialties;

public class Swiftness extends AbstractSpecialty {

    @Override
    public int getSwiftnessBonus() {
        return super.getBonus();
    }
}
