package workForce;

public interface IEmployee {

    int getWorkHoursPerWeek();

}
