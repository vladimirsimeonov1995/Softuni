package workForce;

public class Constants {

    public static final int STANDART_EMPLOYEE_WORKING_HOURS_PER_WEEK = 40;
    public static final int PART_TIME_EMPLOYEE_WORKING_HOURS_PER_WEEK = 20;
    public static final String  TERMINATE_COMMAND = "End";

}
