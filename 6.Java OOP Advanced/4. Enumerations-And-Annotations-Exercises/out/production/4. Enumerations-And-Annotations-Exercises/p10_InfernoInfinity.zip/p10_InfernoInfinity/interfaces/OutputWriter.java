package p10_InfernoInfinity.interfaces;

public interface OutputWriter {

    void writeLine(String text);

    void writeNewLine(String text);
}
