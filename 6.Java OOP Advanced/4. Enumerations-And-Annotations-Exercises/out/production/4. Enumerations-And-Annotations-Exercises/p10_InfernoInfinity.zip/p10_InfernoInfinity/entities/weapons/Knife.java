package p10_InfernoInfinity.entities.weapons;


public class Knife extends Weapon {

    public Knife(String name){
        super(name,3,4,2);
    }


}
