package p10_InfernoInfinity.entities.gems;

public class Amethyst extends Gem {

    public Amethyst(){
        super(2,8,4);
    }

}
