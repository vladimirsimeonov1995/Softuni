package p10_InfernoInfinity.entities.gems;

public class Ruby extends Gem {

    public Ruby() {
        super(7, 2, 5);
    }

}
