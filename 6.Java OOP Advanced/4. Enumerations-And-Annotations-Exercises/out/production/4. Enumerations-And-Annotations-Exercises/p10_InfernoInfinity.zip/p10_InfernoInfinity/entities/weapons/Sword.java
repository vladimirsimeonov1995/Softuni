package p10_InfernoInfinity.entities.weapons;

public class Sword extends Weapon {

    public Sword(String name){
        super(name,4,6,3);
    }

}
