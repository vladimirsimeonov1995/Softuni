package p10_InfernoInfinity.entities.weapons;

public class Axe extends Weapon {

    public Axe(String name) {
        super(name, 5, 10, 4);
    }

}
