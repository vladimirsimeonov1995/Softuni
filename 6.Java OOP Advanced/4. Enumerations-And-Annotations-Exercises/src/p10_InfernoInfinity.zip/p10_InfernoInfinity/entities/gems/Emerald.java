package p10_InfernoInfinity.entities.gems;

public class Emerald extends Gem {

    public Emerald(){
        super(1,4,9);
    }

}
