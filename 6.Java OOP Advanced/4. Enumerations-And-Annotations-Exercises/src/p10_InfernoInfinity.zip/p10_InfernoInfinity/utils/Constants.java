package p10_InfernoInfinity.utils;

public final class Constants {

    public static final String END_COMMAND = "END";

}
