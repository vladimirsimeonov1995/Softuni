package p03_Tuple;

public class Tuple<T , G> {

    private T item1;
    private  G item2;

    public Tuple(T item1,G item2){
        this.item1 = item1;
        this.item2 = item2;
    }


    //{item1} -> {item2}
    @Override
    public String toString() {
        return String.format("%s -> %s",item1,item2);
    }
}
