package p03_Tuple;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));


        for (int i = 0; i < 3; i++) {

            List<String> cmdArgs = Arrays.stream(reader.readLine().split(" ")).collect(Collectors.toList());
            String firstArgument = cmdArgs.get(0);
            String secondArgument = cmdArgs.get(cmdArgs.size()-1);
            cmdArgs.remove(cmdArgs.size()-1);
            if(cmdArgs.size() > 1)
                firstArgument = String.join(" ",cmdArgs);
            Tuple<Object,Object> tuple = new Tuple<>(firstArgument,secondArgument);

            System.out.println(tuple.toString());

        }
    }

}
